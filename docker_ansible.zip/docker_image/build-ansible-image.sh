#!/bin/bash

yes | ssh-keygen -q -t rsa -N '' -f ./id_rsa 
docker build -t docker-ansible .
docker run --rm -it docker-ansible ansible --version
